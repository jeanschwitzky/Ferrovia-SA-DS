CREATE DATABASE IF NOT EXISTS bd_lista_mercado;
USE bd_lista_mercado;

CREATE TABLE IF NOT EXISTS itens (
    id_item INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    descricao_item VARCHAR(255) NOT NULL,
    quantidade_item INT NOT NULL
);

INSERT INTO itens (descricao_item, quantidade_item)
    VALUES
        ('Maçãs', 5),
        ('Leite', 2),
        ('Pão', 1),
        ('Ovos', 12),
        ('Arroz', 1);
