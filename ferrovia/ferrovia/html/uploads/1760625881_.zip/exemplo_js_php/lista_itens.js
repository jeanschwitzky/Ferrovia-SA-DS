document.addEventListener("DOMContentLoaded", function () {
  fetch("pesquisa_itens.php")
    .then((response) => response.json())
    .then((data) => {
      const listaCompras = document.getElementById("lista-compras");
      data.forEach((item) => {
        const listaItem = document.createElement("li");
        listaItem.textContent = `${item.descricao_item}: ${item.quantidade_item}`;
        listaCompras.appendChild(listaItem);
      });
    })
    .catch((error) => console.error("Erro ao buscar itens:", error));
});