<?php

$servidor = "localhost";
$usuario = "root";
$senha = "root";
$banco = "bd_lista_mercado";

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

// Verifica a conexão
if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

?>